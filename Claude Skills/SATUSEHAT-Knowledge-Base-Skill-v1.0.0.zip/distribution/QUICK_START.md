# SATUSEHAT Knowledge Base Skill - Quick Installation

## 📥 Installation Methods

### Method 1: Direct Upload to Claude Desktop (Recommended)

1. **Open Claude Desktop**
2. **Go to Settings** → **Skills** → **Add Skill**
3. **Upload** `satusehat-knowledge-base.skill`
4. **Verify** the skill appears in your skills list

That's it! The skill is now ready to use.

### Method 2: Double-Click Installation (Alternative)

1. **Locate** `satusehat-knowledge-base.skill` file
2. **Double-click** the file
3. Claude Desktop will automatically install it

## ✅ Verify Installation

Open Claude Desktop and test with these queries:

```
"Apa itu platform SATUSEHAT?"
"SATUSEHAT Patient FHIR resource implementation"
"Load quick reference"
```

If Claude responds with detailed SATUSEHAT information, the skill is working correctly.

## ⚙️ Prerequisites

Before installing, ensure you have:

- ✅ **Claude Desktop** installed (latest version)
- ✅ **Brave MCP Server** configured with valid API key
- ✅ **Tavily MCP Server** configured with valid API key

### MCP Configuration

Your `~/.config/Claude/claude_desktop_config.json` should include:

```json
{
  "mcpServers": {
    "brave-search": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-brave-search"],
      "env": {
        "BRAVE_API_KEY": "YOUR_BRAVE_API_KEY"
      }
    },
    "tavily": {
      "command": "docker",
      "args": ["run", "-i", "--rm", "-e", "TAVILY_API_KEY", "mcp/tavily"],
      "env": {
        "TAVILY_API_KEY": "YOUR_TAVILY_API_KEY"
      }
    }
  }
}
```

## 📚 Documentation

After installation, refer to:

1. **README.md** - Complete package overview and navigation
2. **SATUSEHAT_SKILL_INSTALLATION_GUIDE.md** - Detailed usage guide
3. **SATUSEHAT_SKILL_TECHNICAL_DOCS.md** - Technical customization
4. **SATUSEHAT_SKILL_SUMMARY.md** - Executive summary

## 🚀 Quick Start Examples

### For Developers
```
"How do I authenticate with SATUSEHAT API?"
"Show me Patient resource mandatory fields"
"Complete outpatient workflow example"
```

### For System Integrators
```
"Alur interoperabilitas rawat jalan SATUSEHAT"
"SATUSEHAT MedicationRequest dan MedicationDispense"
"Master Patient Index integration guide"
```

### For Learning
```
"Load workflow examples"
"Load quick reference"
"SATUSEHAT authentication flow with code example"
```

## ❓ Troubleshooting

**Skill not triggering?**
- Verify MCP servers are running
- Check API keys are valid
- Restart Claude Desktop
- Include "SATUSEHAT" in your queries

**Need help?**
- Review SATUSEHAT_SKILL_INSTALLATION_GUIDE.md
- Check troubleshooting section in documentation
- Verify prerequisites are met

## 📦 What's Included

- **satusehat-knowledge-base.skill** - Installable skill package (14KB)
- **Documentation Suite** - 74KB of comprehensive guides
  - README.md (16KB) - Package overview
  - SATUSEHAT_SKILL_INSTALLATION_GUIDE.md (13KB) - User guide
  - SATUSEHAT_SKILL_TECHNICAL_DOCS.md (14KB) - Technical docs
  - SATUSEHAT_SKILL_SUMMARY.md (17KB) - Executive summary

---

**Version**: 1.0.0  
**Created**: December 2, 2024  
**Ready to Install**: Yes ✅
